import pg from "pg";
const { Pool } = pg;
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
});
export async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS orders (
      id UUID PRIMARY KEY,
      description TEXT NOT NULL,
      amount_usdt NUMERIC(20,6) NOT NULL CHECK (amount_usdt > 0),
      network TEXT NOT NULL DEFAULT 'TRON-SHASTA',
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS payment_events (
      id BIGSERIAL PRIMARY KEY,
      order_id UUID NOT NULL REFERENCES orders(id),
      txid TEXT UNIQUE NOT NULL,
      from_address TEXT,
      to_address TEXT NOT NULL,
      amount_base_units NUMERIC(40,0) NOT NULL,
      confirmations INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'unverified',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS refund_requests (
      id UUID PRIMARY KEY,
      order_id UUID NOT NULL REFERENCES orders(id),
      reason TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'requested',
      reviewed_by TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      reviewed_at TIMESTAMPTZ
    );
  `);
}