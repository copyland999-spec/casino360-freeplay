import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import crypto from "node:crypto";
import { pool, initDb } from "./db.js";

if (process.env.TRON_NETWORK !== "shasta") {
  throw new Error("This starter is testnet-only. Mainnet crypto payments are disabled.");
}
if (!process.env.DATABASE_URL || !process.env.ADMIN_API_TOKEN) {
  throw new Error("Set DATABASE_URL and ADMIN_API_TOKEN in environment variables.");
}

const app = express();
app.use(helmet());
app.use(express.json({ limit: "32kb" }));
app.use(cors({ origin: process.env.FRONTEND_ORIGIN, methods: ["GET","POST"] }));

const uuid = () => crypto.randomUUID();
const adminOnly = (req,res,next) => {
  const got = req.get("authorization") || "";
  const expected = `Bearer ${process.env.ADMIN_API_TOKEN}`;
  const a = Buffer.from(got), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a,b)) return res.status(401).json({error:"Unauthorized"});
  next();
};

// Example catalog: clients choose a SKU; server controls price.
const CATALOG = {
  "service-basic": { description: "Example digital service", amount: "5.000000" },
  "service-plus": { description: "Example premium service", amount: "12.000000" }
};

app.get("/health", (_req,res) => res.json({ok:true, network:"TRON-SHASTA", mode:"testnet-demo"}));

app.post("/api/orders", async (req,res,next) => {
  try {
    const { sku } = req.body || {};
    if (typeof sku !== "string" || !CATALOG[sku]) return res.status(400).json({error:"Unknown SKU"});
    // This is only a testnet demo. Configure an official test token/address before use.
    const item = CATALOG[sku], id = uuid();
    await pool.query("INSERT INTO orders(id,description,amount_usdt) VALUES($1,$2,$3)", [id,item.description,item.amount]);
    res.status(201).json({
      id, description:item.description, amountUsdt:item.amount,
      network:"TRON-SHASTA", status:"pending",
      message:"Demo only: configure a verified testnet token and deposit address. No real funds accepted."
    });
  } catch(e) { next(e); }
});

app.get("/api/orders/:id", async (req,res,next) => {
  try {
    const { rows } = await pool.query(
      "SELECT id,description,amount_usdt AS amountUsdt,network,status,created_at AS createdAt FROM orders WHERE id=$1",
      [req.params.id]
    );
    if (!rows[0]) return res.status(404).json({error:"Order not found"});
    res.json(rows[0]);
  } catch(e) { next(e); }
});

app.post("/api/orders/:id/refunds", async (req,res,next) => {
  try {
    const { reason } = req.body || {};
    if (typeof reason !== "string" || reason.trim().length < 5 || reason.length > 500)
      return res.status(400).json({error:"Provide a refund reason (5-500 characters)"});
    const order = await pool.query("SELECT id,status FROM orders WHERE id=$1", [req.params.id]);
    if (!order.rows[0]) return res.status(404).json({error:"Order not found"});
    const id = uuid();
    await pool.query("INSERT INTO refund_requests(id,order_id,reason) VALUES($1,$2,$3)", [id,req.params.id,reason.trim()]);
    res.status(201).json({id, orderId:req.params.id, status:"requested",
      message:"No crypto is sent automatically. Admin review and legal approval are required."});
  } catch(e) { next(e); }
});

app.get("/api/admin/refunds", adminOnly, async (_req,res,next) => {
  try {
    const { rows } = await pool.query(`
      SELECT r.id,r.order_id AS "orderId",r.reason,r.status,r.created_at AS "createdAt",
             o.amount_usdt AS "amountUsdt",o.status AS "orderStatus"
      FROM refund_requests r JOIN orders o ON o.id=r.order_id
      ORDER BY r.created_at DESC LIMIT 100`);
    res.json(rows);
  } catch(e) { next(e); }
});

app.post("/api/admin/refunds/:id/review", adminOnly, async (req,res,next) => {
  try {
    const { decision } = req.body || {};
    if (!["approved","rejected"].includes(decision)) return res.status(400).json({error:"decision must be approved or rejected"});
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      const found = await client.query("SELECT id,status FROM refund_requests WHERE id=$1 FOR UPDATE", [req.params.id]);
      if (!found.rows[0]) { await client.query("ROLLBACK"); return res.status(404).json({error:"Refund request not found"}); }
      if (found.rows[0].status !== "requested") { await client.query("ROLLBACK"); return res.status(409).json({error:"Refund already reviewed"}); }
      await client.query(
        "UPDATE refund_requests SET status=$2,reviewed_by='admin-token',reviewed_at=NOW() WHERE id=$1",
        [req.params.id,decision]);
      await client.query("COMMIT");
      res.json({id:req.params.id,status:decision,
        message: decision==="approved" ? "Approved in demo only. This does not broadcast a blockchain transaction." : "Refund request rejected."});
    } catch(e) { await client.query("ROLLBACK"); throw e; }
    finally { client.release(); }
  } catch(e) { next(e); }
});

app.use((err,_req,res,_next) => {
  console.error(err);
  res.status(500).json({error:"Internal server error"});
});

const port = Number(process.env.PORT || 3000);
await initDb();
app.listen(port, () => console.log(`casino360 testnet demo listening on ${port}`));