# casino360 — USDT TRON testnet starter (Node.js + Express + PostgreSQL)

## Important legal and technical limits
This project is deliberately **testnet-only**. It does not accept real USDT, hold private keys, broadcast withdrawals, or provide a production blockchain verifier. Do not switch it to mainnet or use it for real funds. Bangladesh Bank's FE Circular No. 24 (15 Sep 2022) says virtual-currency transactions to/from/in Bangladesh are not permitted; obtain independent Bangladesh legal advice and written regulatory clearance before any real-asset activity. Do not use this for gambling, betting, gaming deposits, or winnings.

## Requirements
- Node.js LTS and PostgreSQL
- A PostgreSQL database on Render (or local)
- Render Web Service connected to this repository
- Official TRON Shasta testnet endpoint and a verified test-token contract, if later implementing testnet chain monitoring

## Run locally
1. Copy `.env.example` to `.env`.
2. Set `DATABASE_URL` and a long random `ADMIN_API_TOKEN`.
3. Keep `TRON_NETWORK=shasta`. Do not add private keys.
4. Run `npm install`, then `npm start`.
5. `GET /health` should return `{"ok":true,"network":"TRON-SHASTA","mode":"testnet-demo"}`.

## Deploy to Render
1. Push the folder to a private GitHub repo.
2. Create a PostgreSQL database in Render and copy its internal connection URL.
3. Create a Web Service from the repo; Build Command `npm install`, Start Command `npm start`.
4. Add environment variables in Render dashboard: `NODE_ENV=production`, `DATABASE_URL`, `ADMIN_API_TOKEN`, `FRONTEND_ORIGIN=https://YOUR-USERNAME.github.io`, `TRON_NETWORK=shasta`.
5. Never commit `.env`, private keys, seed phrases, or credentials.

## Demo endpoints
- `GET /health`
- `POST /api/orders` JSON: `{"sku":"service-basic"}` or `{"sku":"service-plus"}`
- `GET /api/orders/:id`
- `POST /api/orders/:id/refunds` JSON: `{"reason":"Service not delivered"}`
- `GET /api/admin/refunds` header `Authorization: Bearer YOUR_ADMIN_API_TOKEN`
- `POST /api/admin/refunds/:id/review` same header, JSON `{"decision":"approved"}` or `{"decision":"rejected"}`

Refund approval here only changes a database status. It does not transfer tokens. The admin token is a starter placeholder, not a production identity system.

## Production checklist (do not skip)
- Get written legal/regulatory clearance for the business and geography.
- Use a vetted custody/payment provider or a separately audited wallet architecture.
- Do not store a hot-wallet private key in app code, GitHub, or ordinary environment variables; use a managed signer/HSM and withdrawal limits, allowlists, dual approval, and monitoring.
- Build chain indexing against official TRON documentation. Verify the exact official token contract, network, recipient, amount in base units, solidified transaction state, successful TRC-20 Transfer event, and sufficient confirmations. Deduplicate by transaction ID and log every state change.
- Add authentication, role-based access, CSRF protections if cookie auth is used, rate limits, idempotency keys, input validation, audit logs, backups, alerts, and reconciliation.
- Refunds should be to verified original payer address when lawful and technically supported; require manual review. Do not auto-send just because a client requested it.
- Never trust frontend payment status, a screenshot, or a node broadcast response alone.
- Test failure, duplicate webhook, reorg/confirmation, wrong token contract, wrong network, underpayment, overpayment, and replay cases.

## Official technical references
- TRON docs: https://developers.tron.network/docs/getting-started
- TRC-20 interface: https://developers.tron.network/docs/trc20-protocol-interface
- Transaction finality and solidified queries: https://developers.tron.network/reference/transactions
- Bangladesh Bank FE Circular 24/2022: https://www.bb.org.bd/mediaroom/circulars/fepd/sep152022fepd24e.pdf
