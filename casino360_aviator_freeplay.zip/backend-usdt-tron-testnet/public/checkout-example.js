// Load this from a GitHub Pages page. Replace API_BASE with your Render URL.
const API_BASE = "https://YOUR-RENDER-SERVICE.onrender.com";

async function createDemoOrder(sku) {
  const response = await fetch(`${API_BASE}/api/orders`, {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({sku})
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Could not create order");
  // Display data.id, data.amountUsdt, data.network and data.status in the page.
  // Never mark paid based on a client-side button or a screenshot.
  return data;
}
window.createDemoOrder = createDemoOrder;