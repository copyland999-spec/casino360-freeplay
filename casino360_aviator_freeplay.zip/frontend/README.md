# Casino360 Virtual Rewards Frontend

Open `index.html` in a modern browser or run `python -m http.server 8080` in this folder. This bilingual prototype includes free-play mini games, local virtual points/XP, achievements, daily challenge, profile/history, and a leaderboard preview. No real-money betting, deposits, withdrawals or redeemable winnings are present.

The local leaderboard and profile are browser-only and are not secure accounts or shared rankings. See the root README for deployment and production-readiness requirements.
