# Casino360 International Virtual Rewards — Prototype

A redesigned bilingual (English/Bangla), mobile-responsive free-play rewards prototype.

## Included in this version
- Premium responsive dashboard and navigation
- Free-play Orbit Dash and Sky Sprint timing demos
- Virtual points and XP progression
- Achievements and daily challenge
- Leaderboard preview with clearly labelled sample entries
- Local profile, activity history, JSON export and reset controls
- Support FAQ and launch checklist
- English/Bangla interface toggle
- Reduced-motion and keyboard-focus styling

## Important limitations
This is a **front-end prototype**, not a production-ready account platform. User progress is saved in the visitor's browser (`localStorage`); it is not a verified global leaderboard and can be edited or cleared. Sample leaderboard entries are illustrative. There is no server authentication, shared database, live analytics, real customer-support inbox, payment gateway, or admin authorization. Do not use it to collect sensitive personal data.

No real-money betting, casino deposits, cashout, withdrawals, odds, or redeemable winnings are included. Virtual points are free, have no monetary value, and cannot be purchased, transferred, or redeemed.

The existing `backend-bkash-nagad/` folder is a separate starter for legitimate product/service payments only. It is not connected to game points or rewards. The USDT/TRON folder remains a testnet learning demo and is not used by this website.

## Preview locally
Open `frontend/index.html` in a modern browser, or run:
```sh
cd frontend
python -m http.server 8080
```
Then open `http://localhost:8080`.

## Publish a static preview
1. Create a GitHub repository.
2. Upload `frontend/index.html` as `index.html` in the repository root.
3. Open **Settings → Pages**.
4. Choose deployment from the `main` branch and `/(root)`, then save.
5. Test the published page on mobile and desktop.

A custom domain is optional for the prototype; use the free hosting URL first. Follow the hosting provider's instructions to attach a domain and enable HTTPS.

## Before a real public launch
- Build a backend API and managed database for user accounts and shared leaderboard.
- Add server-side authentication, authorization, input validation, rate limits, CSRF protections where applicable, and audit logging.
- Calculate scores and validate achievements on the server; do not trust browser-supplied scores.
- Add backup/restore testing, uptime/error monitoring, secret management and incident response.
- Publish reviewed privacy, terms, data retention and support policies.
- Run accessibility, mobile, browser compatibility, performance and security tests.
- Keep points non-transferable and non-redeemable; do not connect them to payments or cash prizes.
