import pg from 'pg';
const { Pool } = pg;
if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required');
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  max: 5,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});
export async function initDb() {
  await pool.query(`CREATE TABLE IF NOT EXISTS orders (
    id UUID PRIMARY KEY,
    item_name TEXT NOT NULL,
    amount_paisa BIGINT NOT NULL CHECK (amount_paisa > 0),
    currency TEXT NOT NULL DEFAULT 'BDT',
    provider TEXT NOT NULL CHECK (provider IN ('bkash','nagad')),
    status TEXT NOT NULL CHECK (status IN ('pending','paid','failed','cancelled','refund_requested','refund_approved','refunded','refund_rejected')) DEFAULT 'pending',
    provider_payment_id TEXT,
    provider_transaction_id TEXT UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS refunds (
    id UUID PRIMARY KEY,
    order_id UUID NOT NULL REFERENCES orders(id),
    reason TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('requested','approved','rejected','processing','refunded','failed')) DEFAULT 'requested',
    admin_note TEXT,
    provider_refund_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS payment_events (
    id BIGSERIAL PRIMARY KEY,
    order_id UUID,
    event_type TEXT NOT NULL,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);
}
