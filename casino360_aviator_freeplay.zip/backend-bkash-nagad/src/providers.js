/*
 * Provider adapter boundary.
 * IMPORTANT: This scaffold deliberately does not fake a real bKash/Nagad payment.
 * Implement these methods using your merchant's current official API docs + sandbox credentials.
 * Never trust a browser callback alone: query/execute/verify the transaction server-to-server.
 */
export async function createProviderPayment({ provider, order }) {
  if (process.env.PAYMENT_MODE === 'mock') {
    // Local development only. This returns no payment URL and does NOT mark the order paid.
    return { mode: 'mock', message: 'Sandbox scaffold only; configure official provider adapter.' };
  }
  throw new Error(`${provider} adapter is not configured. Follow official merchant API docs before enabling live payments.`);
}

export async function verifyProviderPayment({ provider, order, callbackData }) {
  // TODO: Call official server-side execute/query/verification API.
  // Validate merchant invoice/order, exact amount, currency, and final successful status.
  // Return { success: true, transactionId: 'provider transaction id' } only after verification.
  throw new Error(`${provider} verification adapter is not implemented; never trust callbackData directly.`);
}

export async function issueProviderRefund({ provider, order, refund }) {
  // TODO: Call official provider refund API, then query refund status if supported.
  // Only return success after the provider confirms the refund.
  throw new Error(`${provider} refund adapter is not implemented; no refund was sent.`);
}
