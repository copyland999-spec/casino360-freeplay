import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { randomUUID, timingSafeEqual } from 'node:crypto';
import { z } from 'zod';
import { pool, initDb } from './db.js';
import { createProviderPayment, verifyProviderPayment, issueProviderRefund } from './providers.js';

const app = express();
const PORT = Number(process.env.PORT || 8080);
app.disable('x-powered-by');
app.use(helmet());
const allowedOrigins = (process.env.FRONTEND_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean);
app.use(cors({ origin(origin, cb) { if (!origin || allowedOrigins.includes(origin)) return cb(null, true); return cb(new Error('Origin not allowed')); } }));
app.use(express.json({ limit: '20kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: true, legacyHeaders: false }));

function safeEqual(a, b) {
  if (!a || !b) return false;
  const aa = Buffer.from(a); const bb = Buffer.from(b);
  return aa.length === bb.length && timingSafeEqual(aa, bb);
}
function requireAdmin(req, res, next) {
  const token = req.get('authorization')?.replace(/^Bearer\s+/i, '');
  if (!process.env.ADMIN_API_TOKEN || !safeEqual(token, process.env.ADMIN_API_TOKEN)) return res.status(401).json({ error: 'Unauthorized' });
  next();
}
function publicOrder(row) {
  return { id: row.id, itemName: row.item_name, amount: (Number(row.amount_paisa) / 100).toFixed(2), currency: row.currency, provider: row.provider, status: row.status, createdAt: row.created_at };
}

app.get('/health', (_req, res) => res.json({ ok: true, mode: process.env.PAYMENT_MODE || 'mock' }));

const createOrderSchema = z.object({
  itemName: z.string().trim().min(2).max(120),
  // Amount in BDT. Keep the catalog/price on the server in production; this is a starter example.
  amount: z.coerce.number().finite().positive().max(100000),
  provider: z.enum(['bkash', 'nagad'])
});
app.post('/api/orders', async (req, res, next) => {
  try {
    const parsed = createOrderSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Invalid order details' });
    const { itemName, amount, provider } = parsed.data;
    const amountPaisa = Math.round(amount * 100);
    const id = randomUUID();
    const { rows } = await pool.query(
      `INSERT INTO orders (id,item_name,amount_paisa,provider) VALUES ($1,$2,$3,$4) RETURNING *`,
      [id, itemName, amountPaisa, provider]
    );
    await pool.query('INSERT INTO payment_events (order_id,event_type,details) VALUES ($1,$2,$3)', [id, 'order_created', JSON.stringify({ provider, amount: (amountPaisa / 100).toFixed(2) })]);
    let checkout;
    try { checkout = await createProviderPayment({ provider, order: rows[0] }); }
    catch (e) { return res.status(503).json({ order: publicOrder(rows[0]), error: e.message }); }
    res.status(201).json({ order: publicOrder(rows[0]), checkout });
  } catch (e) { next(e); }
});

app.get('/api/orders/:id', async (req, res, next) => {
  try {
    const { rows } = await pool.query('SELECT * FROM orders WHERE id=$1', [req.params.id]);
    if (!rows[0]) return res.status(404).json({ error: 'Order not found' });
    res.json({ order: publicOrder(rows[0]) });
  } catch (e) { next(e); }
});

// Provider callback endpoint. A callback alone never changes the order to paid.
app.post('/api/payments/:provider/callback', async (req, res, next) => {
  try {
    const provider = req.params.provider;
    if (!['bkash', 'nagad'].includes(provider)) return res.status(400).json({ error: 'Unsupported provider' });
    const schema = z.object({ orderId: z.string().uuid() });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Invalid callback payload' });
    const { rows } = await pool.query('SELECT * FROM orders WHERE id=$1 AND provider=$2', [parsed.data.orderId, provider]);
    const order = rows[0];
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (order.status === 'paid') return res.json({ ok: true, status: 'paid' });
    const verified = await verifyProviderPayment({ provider, order, callbackData: req.body });
    if (!verified.success || !verified.transactionId) return res.status(400).json({ error: 'Payment not verified' });
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const updated = await client.query(`UPDATE orders SET status='paid', provider_transaction_id=$2, updated_at=NOW() WHERE id=$1 AND status='pending' RETURNING id`, [order.id, verified.transactionId]);
      if (updated.rowCount === 1) await client.query('INSERT INTO payment_events (order_id,event_type,details) VALUES ($1,$2,$3)', [order.id, 'payment_verified', JSON.stringify({ provider, transactionId: verified.transactionId })]);
      await client.query('COMMIT');
    } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
    res.json({ ok: true });
  } catch (e) { next(e); }
});

app.post('/api/orders/:id/refunds', async (req, res, next) => {
  try {
    const parsed = z.object({ reason: z.string().trim().min(5).max(500) }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'A refund reason of 5–500 characters is required' });
    const { rows } = await pool.query('SELECT * FROM orders WHERE id=$1', [req.params.id]);
    const order = rows[0];
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (order.status !== 'paid') return res.status(409).json({ error: 'Only paid orders can request a refund' });
    const refundId = randomUUID();
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const lock = await client.query('SELECT status FROM orders WHERE id=$1 FOR UPDATE', [order.id]);
      if (lock.rows[0]?.status !== 'paid') throw new Error('Order is no longer eligible for refund');
      await client.query(`INSERT INTO refunds (id,order_id,reason) VALUES ($1,$2,$3)`, [refundId, order.id, parsed.data.reason]);
      await client.query(`UPDATE orders SET status='refund_requested',updated_at=NOW() WHERE id=$1`, [order.id]);
      await client.query('INSERT INTO payment_events (order_id,event_type,details) VALUES ($1,$2,$3)', [order.id, 'refund_requested', JSON.stringify({ refundId })]);
      await client.query('COMMIT');
    } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
    res.status(201).json({ refundId, status: 'requested', message: 'Refund request submitted for admin review' });
  } catch (e) { next(e); }
});

app.get('/api/admin/refunds', requireAdmin, async (_req, res, next) => {
  try {
    const { rows } = await pool.query(`SELECT r.*, o.item_name, o.amount_paisa, o.provider, o.status AS order_status FROM refunds r JOIN orders o ON o.id=r.order_id ORDER BY r.created_at DESC LIMIT 100`);
    res.json({ refunds: rows.map(r => ({ id: r.id, orderId: r.order_id, itemName: r.item_name, amount: (Number(r.amount_paisa) / 100).toFixed(2), provider: r.provider, reason: r.reason, status: r.status, createdAt: r.created_at })) });
  } catch (e) { next(e); }
});

app.post('/api/admin/refunds/:id/decision', requireAdmin, async (req, res, next) => {
  try {
    const parsed = z.object({ decision: z.enum(['approve', 'reject']), note: z.string().max(500).optional() }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Invalid decision' });
    const client = await pool.connect();
    let refund, order;
    try {
      await client.query('BEGIN');
      const found = await client.query(`SELECT r.id AS refund_id,r.status AS refund_status,r.reason,o.id AS order_id,o.provider,o.provider_transaction_id,o.amount_paisa FROM refunds r JOIN orders o ON o.id=r.order_id WHERE r.id=$1 FOR UPDATE OF r,o`, [req.params.id]);
      if (!found.rows[0]) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'Refund not found' }); }
      const row = found.rows[0];
      if (row.refund_status !== 'requested') { await client.query('ROLLBACK'); return res.status(409).json({ error: 'Refund already handled' }); }
      if (parsed.data.decision === 'reject') {
        await client.query(`UPDATE refunds SET status='rejected',admin_note=$2,updated_at=NOW() WHERE id=$1`, [req.params.id, parsed.data.note || null]);
        await client.query(`UPDATE orders SET status='refund_rejected',updated_at=NOW() WHERE id=$1`, [row.order_id]);
        await client.query('INSERT INTO payment_events (order_id,event_type,details) VALUES ($1,$2,$3)', [row.order_id, 'refund_rejected', JSON.stringify({ refundId: req.params.id })]);
        await client.query('COMMIT');
        return res.json({ ok: true, status: 'rejected' });
      }
      await client.query(`UPDATE refunds SET status='processing',admin_note=$2,updated_at=NOW() WHERE id=$1`, [req.params.id, parsed.data.note || null]);
      await client.query(`UPDATE orders SET status='refund_approved',updated_at=NOW() WHERE id=$1`, [row.order_id]);
      await client.query('COMMIT');
      refund = { id: row.refund_id, reason: row.reason };
      order = { id: row.order_id, provider: row.provider, provider_transaction_id: row.provider_transaction_id, amount_paisa: row.amount_paisa };
    } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
    // Provider refund adapter must be implemented and tested before live approval is enabled.
    try {
      const result = await issueProviderRefund({ provider: order.provider, order, refund });
      await pool.query(`UPDATE refunds SET status='refunded',provider_refund_id=$2,updated_at=NOW() WHERE id=$1`, [refund.id, result.refundId || null]);
      await pool.query(`UPDATE orders SET status='refunded',updated_at=NOW() WHERE id=$1`, [order.id]);
      await pool.query('INSERT INTO payment_events (order_id,event_type,details) VALUES ($1,$2,$3)', [order.id, 'refund_confirmed', JSON.stringify({ refundId: refund.id })]);
      return res.json({ ok: true, status: 'refunded' });
    } catch (e) {
      // Leave status as processing for manual reconciliation; do not claim the money was returned.
      return res.status(503).json({ error: 'Admin approved; provider refund adapter is not configured. No refund was sent.', refundId: refund.id });
    }
  } catch (e) { next(e); }
});

app.use((err, _req, res, _next) => {
  console.error(err.message);
  res.status(500).json({ error: 'Server error' });
});

await initDb();
app.listen(PORT, () => console.log(`casino360 commerce API listening on ${PORT}; mode=${process.env.PAYMENT_MODE || 'mock'}`));
