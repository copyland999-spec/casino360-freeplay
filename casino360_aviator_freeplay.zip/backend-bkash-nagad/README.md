# casino360 commerce payments — Node.js + Express starter

This is a **starter scaffold for legitimate goods/services only**. It is not a live gateway integration. Provider API methods intentionally throw until implemented from your own official merchant docs. Do not use for wagering, gambling deposits, betting balances, or cash-outs.

## Included
- Express API, CORS allowlist, Helmet, rate limiting, Zod validation
- PostgreSQL schema for orders, refunds, audit events
- Order creation and status lookup
- Refund request + bearer-token-protected admin approve/reject workflow
- Provider adapter boundary for bKash and Nagad
- Tiny GitHub Pages checkout example

## Local run
1. Install Node.js 20+.
2. Create a PostgreSQL database (local or hosted).
3. Copy `.env.example` to `.env` and fill `DATABASE_URL`, `FRONTEND_ORIGIN`, and a long random `ADMIN_API_TOKEN`.
4. Keep `PAYMENT_MODE=mock` while developing. Never commit `.env`.
5. Run `npm install`, then `npm start`.
6. Test `GET /health` and use `public/checkout-example.html` after replacing its API URL.

## Deploy on Render
1. Push this folder to a private GitHub repository.
2. Render → New → Web Service → connect the repo; Build command `npm install`, Start command `npm start`.
3. Create Render PostgreSQL, copy its internal connection URL to service environment variable `DATABASE_URL`.
4. Add `NODE_ENV=production`, `PAYMENT_MODE=mock`, `FRONTEND_ORIGIN=https://YOURNAME.github.io` (or exact project Pages URL), `ADMIN_API_TOKEN` (long random secret), `PORT` is supplied by Render.
5. Deploy and test `/health`.

## Official gateway integration is still required
- Obtain the current API docs and sandbox credentials from your bKash and Nagad account managers/official portals.
- Implement `createProviderPayment`, `verifyProviderPayment`, and `issueProviderRefund` in `src/providers.js` using their current official APIs and cryptographic/signature requirements.
- Verify server-to-server final status, exact amount, currency, merchant invoice/order ID, and provider transaction ID. Never trust a client redirect or screenshot.
- Add provider-specific callback routes/validation if the official docs require them. Test success, failure, cancellation, timeout, duplicate callbacks, partial/full refund and refund status queries.
- Only set live credentials in Render Environment after sandbox tests and provider approval. Do not enable live mode while the adapter throws.

## API endpoints
- `GET /health`
- `POST /api/orders` body `{ "itemName":"Sample service", "amount":100, "provider":"bkash" }`
- `GET /api/orders/:id`
- `POST /api/payments/:provider/callback` (scaffold only; will reject until provider verification adapter is implemented)
- `POST /api/orders/:id/refunds` body `{ "reason":"Service not delivered" }`
- `GET /api/admin/refunds` with `Authorization: Bearer <ADMIN_API_TOKEN>`
- `POST /api/admin/refunds/:id/decision` with same header and body `{ "decision":"approve", "note":"Checked order records" }` or `reject`

## Production TODO before accepting money
- Store product IDs and prices on the server; never accept arbitrary amount/item from the browser.
- Use real admin login with MFA, not a shared bearer token, for a public production admin panel.
- Add customer authentication, order ownership checks, CSRF protection if cookie sessions are used, privacy policy, terms, refund policy, structured logs and monitoring.
- Add idempotency keys, webhook signature verification, reconciliation, database backups and retention rules.
- Use least-privilege DB credentials and TLS. Keep all secrets out of GitHub and the frontend.
- This starter is not audited and must be reviewed before production.

## Official links
- bKash developer docs: https://developer.bka.sh/
- bKash sandbox demo: https://merchantdemo.sandbox.bka.sh/
- Nagad official merchant services: https://frontend.nagad.com.bd/services/?service=merchant-pay
- Ask your Nagad account manager for the current official integration guide and sandbox credentials.
